<?php
class Model
{
    public $string;
 
    public function __construct(){
        $this->string = "MVC + PHP equals Awesome, click here!";
    }
 
}
?>
