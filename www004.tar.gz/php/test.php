<html>
<head><title>Test</title></head>
 <body>
  <?php
   $var=array("dale"=>4,"edward"=>5);
   $var["abby"] = 1;
   $var["bill"] = 2;
   $var["charlie"] = 3;
   foreach($var as $key => $elem){
    print "$key is $elem\n";
   }
  ?>
 </body>
</html>
